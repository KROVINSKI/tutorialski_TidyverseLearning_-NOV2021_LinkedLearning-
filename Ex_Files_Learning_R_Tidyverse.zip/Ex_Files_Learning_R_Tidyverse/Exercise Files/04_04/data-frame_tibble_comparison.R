library("tidyverse")

baseR_dataframe <- read.csv("data/timeperiods.csv")

tidyverse_tibble <- read_csv("data/timeperiods.csv")