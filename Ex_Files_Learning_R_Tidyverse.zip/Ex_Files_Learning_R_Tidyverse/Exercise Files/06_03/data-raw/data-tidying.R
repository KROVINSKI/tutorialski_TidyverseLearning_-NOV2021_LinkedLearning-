library("tidyverse")

wide_monthly_tdiff <- read_csv("data-raw/wide_monthly_tdiff.csv")
wide_horses_data <- read_csv("data-raw/wide-horses.csv")
