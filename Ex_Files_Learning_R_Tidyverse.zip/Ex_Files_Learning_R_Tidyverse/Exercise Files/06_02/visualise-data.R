library("tidyverse")

wide_monthly_tdiff <- read_csv("data/wide_monthly_tdiff.csv")

long_monthly_tdiff <- read_csv("data/long_monthly_tdiff.csv")