library("tidyverse")

normal_transport_data <- read_csv("data/transport_data.csv")
## load the grouped_transport_data object
load("data/grouped_transport_data.rdata")